package teamProject;



public class P {
    public int i = -1;
    public int j = -1;

    public int getMax() {
        return Integer.MIN_VALUE;
    }

    public int getMin() {
        return Integer.MAX_VALUE;
    }
}
