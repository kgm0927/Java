package teamProject;
public interface ScoringStrategy {
	 int calculateScore(int count, int c);
}
